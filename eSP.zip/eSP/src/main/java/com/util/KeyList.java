package com.util;

import java.util.List;

public class KeyList {
    private String listName;
    private List list;
}
