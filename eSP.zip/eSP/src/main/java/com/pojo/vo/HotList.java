package com.pojo.vo;

import com.pojo.Hot;

import java.util.List;

public class HotList {
    private List<Hot> hotList;

    public List<Hot> getHotList() {
        return hotList;
    }

    public void setHotList(List<Hot> hotList) {
        this.hotList = hotList;
    }
}
